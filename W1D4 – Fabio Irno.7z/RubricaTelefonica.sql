Drop database if exists RubricaTelefonica;

CREATE DATABASE IF NOT EXISTS RubricaTelefonica
	DEFAULT CHARACTER SET latin1
    DEFAULT COLLATE latin1_general_cs;
    
USE RubricaTelefonica;


drop table if exists COUNTRY;

create table if not exists COUNTRY(
	code varchar(2) not null,
    name varchar(32) not null,
    primary key (code)
);

drop table if exists BRAND;
create table if not exists BRAND(
	id int(11) not null auto_increment,
    name varchar(32) not null,
    country varchar(2) not null,
    primary key (id),
    constraint fk_country foreign key (country) references Country(code)
);



drop table if exists OPSYS;
create table if not exists OPSYS(
	id int(11) not null auto_increment,
    description varchar(64) not null,
    company varchar(64),
    openSource tinyint(1),
    primary key (id)
);

drop table if exists SMARTPHONE;

create table if not exists SMARTPHONE(
	id int(11) not null auto_increment,
    name varchar(64) not null,
    ram varchar(5) not null,
    cpu varchar(64) not null,
    displayPpi int(11) not null,
    displaySize varchar(12) not null,
    displayResolution varchar(64) not null,
    size varchar(64) not null,
    weight int(4) not null,
    notes varchar(1024) not null,
    brand int(11) not null,
    opSys int(11) not null,
    primary key (id),
    constraint fk_brand foreign key (brand) references BRAND(id),
    constraint fk_opSys foreign key (opSys) references OPSYS(id)
);

drop table if exists CONTATTO;

create table if not exists CONTATTO(
	numCellulare  varchar(64) not null primary key,
	nome varchar(64) not null,
    cognome varchar(64) not null, 
    smartphone int(11) not null,
    constraint fk_smartphone foreign key (smartphone) references SMARTPHONE(id)
    );
    

    
    