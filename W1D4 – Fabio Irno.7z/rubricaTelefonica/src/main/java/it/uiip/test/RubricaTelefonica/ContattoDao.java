package it.uiip.test.RubricaTelefonica;

public interface ContattoDao {
	
	public void insert(Contatto contatto);
	public Contatto findByCustomerId(String numCellulare);

}
