package it.uiip.test.RubricaTelefonica;

public class Contatto {
	
	String numCellulare;
	String nome;
    String cognome;
    static int smartphone;
    
    
    
    
	public Contatto(String numCellulare, String nome, String cognome, int smartphone) {
		super();
		this.numCellulare = numCellulare;
		this.nome = nome;
		this.cognome = cognome;
		this.smartphone = smartphone;
	}
	
	
	public String getNumCellulare() {
		return numCellulare;
	}
	public void setNumCellulare(String numCellulare) {
		this.numCellulare = numCellulare;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public int getSmartphone() {
		return smartphone;
	}
	public void setSmartphone(int smartphone) {
		this.smartphone = smartphone;
	}
    
        

}
