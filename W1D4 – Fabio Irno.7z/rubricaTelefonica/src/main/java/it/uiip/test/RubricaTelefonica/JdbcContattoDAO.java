package it.uiip.test.RubricaTelefonica;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class JdbcContattoDAO extends Contatto {
	
public JdbcContattoDAO(String numCellulare, String nome, String cognome, int smartphone) {
		super(numCellulare, nome, cognome, smartphone);
		// TODO Auto-generated constructor stub
	}

private static DataSource dataSource;
	
	public void setDataSource(Contatto contatto) {
		this.dataSource = dataSource;
	}
	
	public static void insert(Contatto contatto){
		
		String sql = "INSERT INTO CONTATTO " +
				"(numCellulare,nome,cognome,smartphone) VALUES (?, ?, ?,?)";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, contatto.getNumCellulare());
			ps.setString(2, contatto.getNome());
			ps.setString(3, contatto.getCognome());
			ps.setInt(4,contatto.smartphone);
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public static Contatto findByCustomerId(int custId){
		
		String sql = "SELECT * FROM CONTATTO WHERE SMARTPHONE = ?";
		
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "numCellulare");
			Contatto contatto = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				contatto = new Contatto(
					rs.getString("numCellulare"),
					rs.getString("nome"),
					rs.getString("cognome"),
					rs.getInt(smartphone)
				);
			}
			rs.close();
			ps.close();
			return contatto;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

}
